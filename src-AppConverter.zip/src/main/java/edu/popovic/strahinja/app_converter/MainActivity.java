package edu.popovic.strahinja.app_converter;

import android.app.Activity;
import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.text.DecimalFormat;

public class MainActivity extends ActionBarActivity
{
    private String temperatureString = ""; //String for text field temperature number
    private String resultCalculationDecimalFormat = ""; //String for decimal format
    DecimalFormat df = new DecimalFormat("0.00"); //Decimal format object
    private double temperatureDouble = 0.00;
    private double resultMessage = 0.00;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        //overridePendingTransition(R.anim.abc_fade_in, R.anim.abc_fade_out);

        setContentView(R.layout.activity_main);

        setupUI(findViewById(R.id.homeLayout));

        //Components declarisation

        final RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        final RadioButton radioC = (RadioButton) findViewById(R.id.radioCelsius);
        final RadioButton radioF = (RadioButton) findViewById(R.id.radioFahrenheit);

        final EditText temperature = (EditText) findViewById(R.id.textTemperature);

        final EditText result = (EditText) findViewById(R.id.txtResult);

        final Button btnCalculate = (Button) findViewById(R.id.btnCalculate);
        final Button btnReset = (Button) findViewById(R.id.btnReset);
        final Button btnWhiteApp = (Button) findViewById(R.id.btnWhiteApp);
        final Button btnBlackApp = (Button) findViewById(R.id.btnBlackApp);
        final Button btnDescription = (Button) findViewById(R.id.btnDescription);

        final ImageView celBlogLink = (ImageView) findViewById(R.id.imgViewCelB);
        final ImageView linkedInLink = (ImageView) findViewById(R.id.imgViewIn);
        final ImageView twitterLink = (ImageView) findViewById(R.id.imgViewTw);
        final ImageView facebookLink = (ImageView) findViewById(R.id.imgViewFb);
        final ImageView freelancerLink = (ImageView) findViewById(R.id.imgViewFrl);
        final ImageView gplusLink = (ImageView) findViewById(R.id.imgViewGp);

        btnCalculate.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                temperatureString = temperature.getText().toString();//Forming String

                if(v.getId() == R.id.btnCalculate)
                {
                    if(radioGroup.getCheckedRadioButtonId() == R.id.radioCelsius)
                    {
                        if(temperatureString.equalsIgnoreCase(""))
                        {
                            result.setText("Insert a number for degrees in ( "
                                    + (char) 0x00B0 + " C )");
                        }
                        else if(!temperatureString.equalsIgnoreCase(""))
                        {
                            try
                            {
                                temperatureDouble = Double.parseDouble(temperatureString);
                                resultMessage = temperatureDouble * 9/5 + 32;
                                resultCalculationDecimalFormat = df.format(resultMessage);
                                result.setText("= " + resultCalculationDecimalFormat + " ( "
                                        + (char) 0x00B0 + " F )");
                            }
                            catch (NumberFormatException ex)
                            {
                                result.setText("Numbers are allowed only");
                                temperature.setText("");
                            }
                        }
                    }
                    else if(radioGroup.getCheckedRadioButtonId() == R.id.radioFahrenheit)
                    {
                        if(temperatureString.equalsIgnoreCase(""))
                        {
                            result.setText("Insert a number for degrees in ( "
                                    + (char) 0x00B0 + " F )");
                        }
                        else if(!temperatureString.equalsIgnoreCase(""))
                        {
                            try
                            {
                                temperatureDouble = Double.parseDouble(temperatureString);
                                resultMessage = (temperatureDouble - 32) * 5/9;
                                resultCalculationDecimalFormat = df.format(resultMessage);
                                result.setText("= " + resultCalculationDecimalFormat + " ( "
                                        + (char) 0x00B0 + " C )");
                            }
                            catch (NumberFormatException ex)
                            {
                                result.setText("Numbers are allowed only");
                                temperature.setText("");
                            }
                        }
                    }
                }
            }
        });
        btnReset.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                InputMethodManager inputManager = (InputMethodManager)
                        getSystemService(Context.INPUT_METHOD_SERVICE);

                inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
                        InputMethodManager.HIDE_NOT_ALWAYS);

                if(v.getId() == R.id.btnReset)
                {
                    if(radioGroup.getCheckedRadioButtonId() == R.id.radioCelsius)
                    {
                        temperature.setText("");
                        result.setText("");
                    }
                    else
                    {
                        radioC.setChecked(true);
                        temperature.setText("");
                        result.setText("");
                    }
                }
            }
        });

        btnBlackApp.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(MainActivity.this, BlackActivity.class));
            }
        });

        btnDescription.setOnClickListener(new View.OnClickListener()
        {
            float zoomFactor = 2f;
            boolean zoomedOut = false;

            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(MainActivity.this, DescriptionActivity.class));
            }
        });

        celBlogLink.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent();
                i.setAction(Intent.ACTION_VIEW);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setData(Uri.parse("http://www.connectinglogix.com/celBlog/"));
                startActivity(i);
            }
        });

        linkedInLink.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent();
                i.setAction(Intent.ACTION_VIEW);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setData(Uri.parse("https://www.linkedin.com/in/strahinja-popovic-b76902117/"));
                startActivity(i);
            }
        });

        twitterLink.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent();
                i.setAction(Intent.ACTION_VIEW);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setData(Uri.parse("https://twitter.com/CodexWebService"));
                startActivity(i);
            }
        });

        facebookLink.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent();
                i.setAction(Intent.ACTION_VIEW);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setData(Uri.parse("https://www.facebook.com/strahinja.popovic.37"));
                startActivity(i);
            }
        });

        freelancerLink.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent();
                i.setAction(Intent.ACTION_VIEW);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setData(Uri.parse("https://www.freelancer.com/u/codexdeveloper.html"));
                startActivity(i);
            }
        });

        gplusLink.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent();
                i.setAction(Intent.ACTION_VIEW);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setData(Uri.parse("https://plus.google.com/100617731713699204161"));
                startActivity(i);
            }
        });
    }

    public static void hideSoftKeyboard(Activity activity)
    {
        InputMethodManager inputMethodManager =
                (InputMethodManager)  activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
    }

    public void setupUI(View view)
    {
        //Set up touch listener for non-text box views to hide keyboard.
        if(!(view instanceof EditText))
        {
            view.setOnTouchListener(new View.OnTouchListener()
            {
                public boolean onTouch(View v, MotionEvent event)
                {
                    hideSoftKeyboard(MainActivity.this);
                    return false;
                }
            });
        }

        //If a layout container, iterate over children and seed recursion.
        if (view instanceof ViewGroup)
        {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++)
            {
                View innerView = ((ViewGroup) view).getChildAt(i);
                setupUI(innerView);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        Intent i = new Intent();
        //noinspection SimplifiableIfStatement

        switch(id)
        {
            case R.id.black_mode:
                i = new Intent(MainActivity.this, BlackActivity.class);
                startActivity(i);
                return true;

            case R.id.description:
                i = new Intent(MainActivity.this, DescriptionActivity.class);
                startActivity(i);
                return true;
        }
        /*
        if(id == R.id.action_menu)
        {
            return true;
        }
        else if(id == R.id.black_mode)
        {
            return true;
        }
        else if(id == R.id.description)
        {
            return true;
        }
        */
        return super.onOptionsItemSelected(item);
    }
}
